package com.example.educonnect;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class PomodoroFragment extends Fragment {

    private TextView timerTextView, historyTextView;
    private EditText inputMinutes;
    private Button startTimerBtn, stopTimerBtn;
    private CountDownTimer countDownTimer;
    private boolean isTimerRunning = false;
    private long timeLeftInMillis;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_pomodoro, container, false);

        timerTextView = view.findViewById(R.id.timerTextView);
        historyTextView = view.findViewById(R.id.historyTextView);
        inputMinutes = view.findViewById(R.id.inputMinutes);
        startTimerBtn = view.findViewById(R.id.startTimerBtn);
        stopTimerBtn = view.findViewById(R.id.stopTimerBtn);

        startTimerBtn.setOnClickListener(v -> startTimer());
        stopTimerBtn.setOnClickListener(v -> stopTimer());

        loadHistory();  // Load past Pomodoro sessions

        return view;
    }

    private void startTimer() {
        if (isTimerRunning) return;

        String input = inputMinutes.getText().toString();
        if (input.isEmpty()) {
            Toast.makeText(getContext(), "Enter duration in minutes", Toast.LENGTH_SHORT).show();
            return;
        }

        timeLeftInMillis = Integer.parseInt(input) * 60 * 1000;

        countDownTimer = new CountDownTimer(timeLeftInMillis, 1000) {
            public void onTick(long millisUntilFinished) {
                timeLeftInMillis = millisUntilFinished;
                updateTimerDisplay();
            }

            public void onFinish() {
                isTimerRunning = false;
                logSession();
                savePomodoroSession();
                updateTimerDisplay();
                Toast.makeText(getContext(), "Pomodoro Completed!", Toast.LENGTH_SHORT).show();
            }
        }.start();

        isTimerRunning = true;
    }

    private void stopTimer() {
        if (countDownTimer != null) countDownTimer.cancel();
        isTimerRunning = false;
        Toast.makeText(getContext(), "Timer Stopped.", Toast.LENGTH_SHORT).show();
    }

    private void updateTimerDisplay() {
        int minutes = (int) (timeLeftInMillis / 1000) / 60;
        int seconds = (int) (timeLeftInMillis / 1000) % 60;
        timerTextView.setText(String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds));
    }

    private void logSession() {
        String time = new SimpleDateFormat("hh:mm a", Locale.getDefault()).format(new Date());
        historyTextView.append("✅ Session at " + time + "\n");
    }

    private void savePomodoroSession() {
        SharedPreferences prefs = getActivity().getSharedPreferences("PomodoroHistory", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();

        String existingHistory = prefs.getString("history", "");
        existingHistory = "✅ " + new SimpleDateFormat("hh:mm a", Locale.getDefault()).format(new Date()) + "\n" + existingHistory;

        editor.putString("history", existingHistory);
        editor.apply();
    }

    private void loadHistory() {
        SharedPreferences prefs = getActivity().getSharedPreferences("PomodoroHistory", Context.MODE_PRIVATE);
        String history = prefs.getString("history", "No history available");
        historyTextView.setText(history);
    }
}
