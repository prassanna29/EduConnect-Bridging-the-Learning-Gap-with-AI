package com.example.educonnect;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import java.util.ArrayList;
import java.util.List;

public class FlashcardsFragment extends Fragment {

    private EditText questionInput, answerInput;
    private Button addFlashcardBtn, showAnswerBtn;
    private TextView questionTextView, answerTextView;
    private List<Flashcard> flashcards;
    private int currentIndex = 0;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_flashcards, container, false);

        questionInput = view.findViewById(R.id.questionInput);
        answerInput = view.findViewById(R.id.answerInput);
        addFlashcardBtn = view.findViewById(R.id.addFlashcardBtn);
        showAnswerBtn = view.findViewById(R.id.showAnswerBtn);
        questionTextView = view.findViewById(R.id.questionTextView);
        answerTextView = view.findViewById(R.id.answerTextView);

        flashcards = new ArrayList<>();

        addFlashcardBtn.setOnClickListener(v -> addFlashcard());
        showAnswerBtn.setOnClickListener(v -> showAnswer());

        return view;
    }

    private void addFlashcard() {
        String question = questionInput.getText().toString().trim();
        String answer = answerInput.getText().toString().trim();

        if (question.isEmpty() || answer.isEmpty()) {
            Toast.makeText(getContext(), "Enter question and answer!", Toast.LENGTH_SHORT).show();
            return;
        }

        flashcards.add(new Flashcard(question, answer));
        questionInput.setText("");
        answerInput.setText("");
        Toast.makeText(getContext(), "Flashcard Added!", Toast.LENGTH_SHORT).show();
    }

    private void showAnswer() {
        if (flashcards.isEmpty()) {
            Toast.makeText(getContext(), "No flashcards added!", Toast.LENGTH_SHORT).show();
            return;
        }

        Flashcard flashcard = flashcards.get(currentIndex);
        questionTextView.setText("Q: " + flashcard.getQuestion());
        answerTextView.setText("A: " + flashcard.getAnswer());
        answerTextView.setVisibility(View.VISIBLE);

        currentIndex = (currentIndex + 1) % flashcards.size();
    }
}
