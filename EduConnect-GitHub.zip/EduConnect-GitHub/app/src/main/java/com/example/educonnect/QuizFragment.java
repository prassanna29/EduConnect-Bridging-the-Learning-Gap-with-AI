package com.example.educonnect;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

public class QuizFragment extends Fragment {

    private static final int PICK_PDF_REQUEST = 1;
    private Uri selectedPdfUri;
    private Button selectPdfBtn, generateQuizBtn;
    private TextView quizTextView;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_quiz, container, false);

        selectPdfBtn = view.findViewById(R.id.selectPdfBtn);
        generateQuizBtn = view.findViewById(R.id.generateQuizBtn);
        quizTextView = view.findViewById(R.id.quizTextView);

        selectPdfBtn.setOnClickListener(v -> selectPdf());
        generateQuizBtn.setOnClickListener(v -> displayQuizFromCSV());

        return view;
    }

    private void selectPdf() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("application/pdf");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(Intent.createChooser(intent, "Select PDF"), PICK_PDF_REQUEST);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_PDF_REQUEST && resultCode == Activity.RESULT_OK && data != null) {
            selectedPdfUri = data.getData();
            Toast.makeText(getContext(), "PDF selected successfully!", Toast.LENGTH_SHORT).show();
        }
    }

    private void displayQuizFromCSV() {
        try {
            InputStream is = getContext().getAssets().open("generated_quiz.csv");
            BufferedReader reader = new BufferedReader(new InputStreamReader(is));

            StringBuilder questionsBuilder = new StringBuilder();
            String line;
            boolean isFirstLine = true;

            while ((line = reader.readLine()) != null) {
                if (isFirstLine) {
                    isFirstLine = false; // Skip header
                    continue;
                }

                String[] parts = line.split(",");
                if (parts.length >= 2) {
                    String question = parts[0];
                    String answer = parts[1];
                    questionsBuilder.append("Q: ").append(question).append("\n")
                            .append("A: ").append(answer).append("\n\n");
                }
            }

            reader.close();
            quizTextView.setText(questionsBuilder.toString());

        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(getContext(), "Error reading quiz file", Toast.LENGTH_SHORT).show();
        }
    }
}
