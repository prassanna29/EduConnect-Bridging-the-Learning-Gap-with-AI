plugins {
    id("com.android.application")
}

android {
    compileSdk = 34
    namespace = "com.example.educonnect"

    defaultConfig {
        applicationId = "com.example.educonnect"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        // Allowing File Provider for PDF Selection & Downloading
        vectorDrawables.useSupportLibrary = true
    }


    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
    packaging {
        resources.excludes.add("META-INF/INDEX.LIST")
        resources.excludes.add("META-INF/DEPENDENCIES")
    }
}


dependencies {
    // Core dependencies
    implementation("androidx.core:core-ktx:1.12.0") {
        exclude(group = "com.android.support", module = "support-compat")
    }
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")
    implementation("androidx.cardview:cardview:1.0.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("com.google.mlkit:translate:17.0.2")

    implementation("com.squareup.okhttp3:okhttp:4.9.3")
    implementation ("com.google.code.gson:gson:2.9.0")
   
    implementation("com.github.barteksc:AndroidPdfViewer:3.1.0-beta.1")


    implementation("com.itextpdf:itextpdf:5.5.13.2")

    implementation("com.tom-roush:pdfbox-android:2.0.27.0")


    implementation ("com.google.mlkit:text-recognition:16.0.0")

    implementation("com.google.cloud:google-cloud-speech:2.6.0")
    implementation ("androidx.fragment:fragment:1.5.5")



    implementation("com.karumi:dexter:6.2.2")
    configurations.all {
        resolutionStrategy {
            force("com.google.protobuf:protobuf-java:3.21.7")
        }
    }
}
