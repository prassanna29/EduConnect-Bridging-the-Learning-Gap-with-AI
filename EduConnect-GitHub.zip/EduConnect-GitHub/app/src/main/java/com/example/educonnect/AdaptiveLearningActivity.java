package com.example.educonnect;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class AdaptiveLearningActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Directly start the DrawableLayout (which has the navigation drawer and features)
        Intent intent = new Intent(this, DrawableLayout.class);
        startActivity(intent);
        finish(); // Optional: close this activity so user doesn't come back to it when pressing back
    }
}
