package com.example.educonnect;

import android.Manifest;
import android.content.Intent;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.widget.Button;
import android.widget.TextView;
import android.database.Cursor;
import android.provider.OpenableColumns;

import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import com.google.cloud.speech.v1.*;
import com.google.protobuf.ByteString;
import com.itextpdf.text.Document;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class DeafAssistActivity extends AppCompatActivity {

    private static final int PICK_AUDIO_FILE = 1;
    private TextView selectedFileName, transcribedText;
    private Button selectAudioBtn, convertToTextBtn, downloadTextBtn, startRecordingBtn, stopRecordingBtn, startLiveSpeechBtn, stopLiveSpeechBtn;
    private Uri selectedAudioUri;
    private MediaRecorder mediaRecorder;
    private String recordedAudioPath = "";
    private SpeechRecognizer speechRecognizer;
    private Intent speechIntent;
    private String audioFileName = "transcription";


    private void selectAudioFile() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("audio/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(intent, PICK_AUDIO_FILE);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_AUDIO_FILE && resultCode == RESULT_OK && data != null) {
            selectedAudioUri = data.getData();

            String fileName = getFileName(selectedAudioUri);
            selectedFileName.setText(fileName);
        }
    }

    private String getFileName(Uri uri) {
        String result = null;

        if (uri.getScheme().equals("content")) {
            try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
                if (cursor != null && cursor.moveToFirst()) {
                    int nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                    if (nameIndex != -1) {
                        result = cursor.getString(nameIndex);
                    }
                }
            }
        }

        if (result == null) {
            result = uri.getPath();
            int cut = result.lastIndexOf('/');
            if (cut != -1) {
                result = result.substring(cut + 1);
            }
        }

        return result;
    }




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_deaf_assist);

        selectedFileName = findViewById(R.id.selectedFileName);
        transcribedText = findViewById(R.id.transcribedText);
        selectAudioBtn = findViewById(R.id.selectAudioBtn);
        convertToTextBtn = findViewById(R.id.convertToTextBtn);
        downloadTextBtn = findViewById(R.id.downloadTextBtn);
        startRecordingBtn = findViewById(R.id.startRecordingBtn);
        stopRecordingBtn = findViewById(R.id.stopRecordingBtn);
        startLiveSpeechBtn = findViewById(R.id.startLiveSpeechBtn);
        stopLiveSpeechBtn = findViewById(R.id.stopLiveSpeechBtn);

        stopRecordingBtn.setEnabled(false);
        stopLiveSpeechBtn.setEnabled(false);

        ActivityCompat.requestPermissions(this, new String[]{
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.READ_EXTERNAL_STORAGE
        }, 1);

        selectAudioBtn.setOnClickListener(v -> selectAudioFile());
        convertToTextBtn.setOnClickListener(v -> transcribeAudioFile());
        downloadTextBtn.setOnClickListener(v -> downloadTranscription());
        startRecordingBtn.setOnClickListener(v -> startRecording());
        stopRecordingBtn.setOnClickListener(v -> stopRecording());
        startLiveSpeechBtn.setOnClickListener(v -> startLiveSpeechToText());
        stopLiveSpeechBtn.setOnClickListener(v -> stopLiveSpeechToText());
    }


    private void startRecording() {
        try {
            File downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            File audioFile = new File(downloadsDir, "recorded_audio.3gp");
            recordedAudioPath = audioFile.getAbsolutePath();

            mediaRecorder = new MediaRecorder();
            mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
            mediaRecorder.setOutputFile(recordedAudioPath);
            mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
            mediaRecorder.prepare();
            mediaRecorder.start();

            startRecordingBtn.setEnabled(false);
            stopRecordingBtn.setEnabled(true);
            Toast.makeText(this, "Recording started...", Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Recording failed!", Toast.LENGTH_SHORT).show();
        }
    }


    private void stopRecording() {
        if (mediaRecorder != null) {
            mediaRecorder.stop();
            mediaRecorder.release();
            mediaRecorder = null;

            startRecordingBtn.setEnabled(true);
            stopRecordingBtn.setEnabled(false);
            Toast.makeText(this, "Recording saved in Downloads!", Toast.LENGTH_SHORT).show();
        }
    }


    private void startLiveSpeechToText() {
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
        speechIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        speechIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        speechIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());

        speechRecognizer.setRecognitionListener(new RecognitionListener() {
            @Override
            public void onReadyForSpeech(Bundle params) {}

            @Override
            public void onBeginningOfSpeech() {}

            @Override
            public void onRmsChanged(float rmsdB) {}

            @Override
            public void onBufferReceived(byte[] buffer) {}

            @Override
            public void onEndOfSpeech() {}

            @Override
            public void onError(int error) {
                Toast.makeText(DeafAssistActivity.this, "Speech recognition error!", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onResults(Bundle results) {
                ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (matches != null) {
                    transcribedText.setText(matches.get(0));
                }
            }

            @Override
            public void onPartialResults(Bundle partialResults) {}

            @Override
            public void onEvent(int eventType, Bundle params) {}
        });

        speechRecognizer.startListening(speechIntent);
        startLiveSpeechBtn.setEnabled(false);
        stopLiveSpeechBtn.setEnabled(true);
    }

    private void stopLiveSpeechToText() {
        if (speechRecognizer != null) {
            speechRecognizer.stopListening();
            startLiveSpeechBtn.setEnabled(true);
            stopLiveSpeechBtn.setEnabled(false);
        }
    }


    private void transcribeAudioFile() {
        if (selectedAudioUri == null) {
            Toast.makeText(this, "Please select an audio file first!", Toast.LENGTH_SHORT).show();
            return;
        }

        new Thread(() -> {
            try {

                InputStream inputStream = getContentResolver().openInputStream(selectedAudioUri);
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                byte[] buffer = new byte[1024];
                int bytesRead;
                while ((bytesRead = inputStream.read(buffer)) != -1) {
                    byteArrayOutputStream.write(buffer, 0, bytesRead);
                }
                inputStream.close();
                byte[] audioBytes = byteArrayOutputStream.toByteArray();


                RecognitionAudio audio = RecognitionAudio.newBuilder()
                        .setContent(ByteString.copyFrom(audioBytes))
                        .build();


                RecognitionConfig config = RecognitionConfig.newBuilder()
                        .setEncoding(RecognitionConfig.AudioEncoding.LINEAR16)
                        .setSampleRateHertz(16000)
                        .setLanguageCode("en-US")
                        .build();


                SpeechClient speechClient = SpeechClient.create();
                List<SpeechRecognitionResult> results = speechClient.recognize(config, audio).getResultsList();


                StringBuilder resultText = new StringBuilder();
                for (SpeechRecognitionResult result : results) {
                    SpeechRecognitionAlternative alternative = result.getAlternativesList().get(0);
                    resultText.append(alternative.getTranscript()).append("\n");
                }

                String finalText = resultText.toString();
                runOnUiThread(() -> transcribedText.setText(finalText));

                speechClient.close();
            } catch (Exception e) {
                e.printStackTrace();
                runOnUiThread(() -> Toast.makeText(this, "Transcription failed! Check file format.", Toast.LENGTH_SHORT).show());
            }
        }).start();
    }



    private void downloadTranscription() {
        String text = transcribedText.getText().toString();
        if (text.isEmpty()) {
            Toast.makeText(this, "No transcription available to download!", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            File downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            File pdfFile = new File(downloadsDir, "transcription.pdf");

            Document document = new Document();
            PdfWriter.getInstance(document, new FileOutputStream(pdfFile));
            document.open();
            document.add(new Paragraph(text));
            document.close();

            Toast.makeText(this, "Transcription saved as PDF in Downloads!", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Failed to save transcription!", Toast.LENGTH_SHORT).show();
        }
    }
}
