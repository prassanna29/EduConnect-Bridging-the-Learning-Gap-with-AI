package com.example.educonnect;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.parser.PdfTextExtractor;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Locale;

public class BlindAssistActivity extends AppCompatActivity {
    private static final int PICK_PDF_FILE = 1;
    private Uri selectedPdfUri;
    private TextView selectedFileName, brailleOutput;
    private EditText inputText;
    private TextToSpeech textToSpeech;
    private Button convertToBrailleBtn, startTextSpeechBtn, stopTextSpeechBtn;
    private Button selectPdfBtn, convertPdfToBrailleBtn, startPdfSpeechBtn, stopPdfSpeechBtn;
    private ScrollView scrollViewBraille;
    private String extractedPdfText = "";

    private static final HashMap<Character, String> brailleMap = new HashMap<>();

    static {
        brailleMap.put('a', "⠁"); brailleMap.put('b', "⠃"); brailleMap.put('c', "⠉");
        brailleMap.put('d', "⠙"); brailleMap.put('e', "⠑"); brailleMap.put('f', "⠋");
        brailleMap.put('g', "⠛"); brailleMap.put('h', "⠓"); brailleMap.put('i', "⠊");
        brailleMap.put('j', "⠚"); brailleMap.put('k', "⠅"); brailleMap.put('l', "⠇");
        brailleMap.put('m', "⠍"); brailleMap.put('n', "⠝"); brailleMap.put('o', "⠕");
        brailleMap.put('p', "⠏"); brailleMap.put('q', "⠟"); brailleMap.put('r', "⠗");
        brailleMap.put('s', "⠎"); brailleMap.put('t', "⠞"); brailleMap.put('u', "⠥");
        brailleMap.put('v', "⠧"); brailleMap.put('w', "⠺"); brailleMap.put('x', "⠭");
        brailleMap.put('y', "⠽"); brailleMap.put('z', "⠵");
        brailleMap.put(' ', " ");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_blind_assist);

        selectedFileName = findViewById(R.id.selectedFileName);
        inputText = findViewById(R.id.inputText);
        brailleOutput = findViewById(R.id.brailleOutput);
        scrollViewBraille = findViewById(R.id.scrollViewBraille);

        convertToBrailleBtn = findViewById(R.id.convertToBrailleBtn);
        startTextSpeechBtn = findViewById(R.id.startTextSpeechBtn);
        stopTextSpeechBtn = findViewById(R.id.stopTextSpeechBtn);
        selectPdfBtn = findViewById(R.id.selectPdfBtn);
        convertPdfToBrailleBtn = findViewById(R.id.convertPdfToBrailleBtn);
        startPdfSpeechBtn = findViewById(R.id.startPdfSpeechBtn);
        stopPdfSpeechBtn = findViewById(R.id.stopPdfSpeechBtn);

        textToSpeech = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                textToSpeech.setLanguage(Locale.US);
            }
        });

        convertToBrailleBtn.setOnClickListener(v -> convertTextToBraille());
        startTextSpeechBtn.setOnClickListener(v -> startTextSpeech());
        stopTextSpeechBtn.setOnClickListener(v -> stopSpeech());
        selectPdfBtn.setOnClickListener(v -> selectPdfFile());
        convertPdfToBrailleBtn.setOnClickListener(v -> convertPdfToBraille());
        startPdfSpeechBtn.setOnClickListener(v -> startPdfSpeech());
        stopPdfSpeechBtn.setOnClickListener(v -> stopSpeech());

        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 1);
    }

    private void convertTextToBraille() {
        String text = inputText.getText().toString().toLowerCase();
        if (text.isEmpty()) {
            showPopupMessage("Please enter text before converting to Braille.");
            return;
        }
        StringBuilder brailleText = new StringBuilder();
        for (char c : text.toCharArray()) {
            brailleText.append(brailleMap.getOrDefault(c, " "));
        }
        brailleOutput.setText(brailleText.toString());
    }

    private void selectPdfFile() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("application/pdf");
        startActivityForResult(intent, PICK_PDF_FILE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_PDF_FILE && resultCode == RESULT_OK && data != null) {
            selectedPdfUri = data.getData();
            selectedFileName.setText(getFileNameFromUri(selectedPdfUri));

            // Extract text immediately after selecting PDF
            extractTextFromPdf();
        }
    }

    private void extractTextFromPdf() {
        if (selectedPdfUri == null) {
            showPopupMessage("Please select a PDF first.");
            return;
        }

        try {
            InputStream inputStream = getContentResolver().openInputStream(selectedPdfUri);
            PdfReader reader = new PdfReader(inputStream);
            StringBuilder extractedText = new StringBuilder();

            for (int i = 1; i <= reader.getNumberOfPages(); i++) {
                extractedText.append(PdfTextExtractor.getTextFromPage(reader, i)).append("\n");
            }
            reader.close();

            extractedPdfText = extractedText.toString().trim();
            if (extractedPdfText.isEmpty()) {
                showPopupMessage("No text found in PDF.");
            }
        } catch (Exception e) {
            showPopupMessage("Error extracting text from PDF.");
            e.printStackTrace();
        }
    }

    private void convertPdfToBraille() {
        if (extractedPdfText.isEmpty()) {
            showPopupMessage("No text found in PDF. Try selecting another file.");
            return;
        }

        String brailleText = convertToBraille(extractedPdfText);
        brailleOutput.setText(brailleText);
    }

    private String convertToBraille(String text) {
        StringBuilder brailleText = new StringBuilder();
        for (char c : text.toLowerCase().toCharArray()) {
            brailleText.append(brailleMap.getOrDefault(c, " "));
        }
        return brailleText.toString();
    }

    private void startPdfSpeech() {
        if (extractedPdfText.isEmpty()) {
            showPopupMessage("No text found in PDF. Please select a PDF first.");
            return;
        }
        textToSpeech.speak(extractedPdfText, TextToSpeech.QUEUE_FLUSH, null, null);
    }

    private void startTextSpeech() {
        String text = inputText.getText().toString();
        if (text.isEmpty()) {
            showPopupMessage("Please enter text before starting speech.");
            return;
        }
        textToSpeech.speak(text, TextToSpeech.QUEUE_FLUSH, null, null);
    }

    private void stopSpeech() {
        textToSpeech.stop();
    }

    private String getFileNameFromUri(Uri uri) {
        Cursor cursor = getContentResolver().query(uri, null, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            int nameIndex = cursor.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME);
            String name = cursor.getString(nameIndex);
            cursor.close();
            return name;
        }
        return "Unknown File";
    }

    private void showPopupMessage(String message) {
        new AlertDialog.Builder(this).setMessage(message).setPositiveButton("OK", null).show();
    }
}
