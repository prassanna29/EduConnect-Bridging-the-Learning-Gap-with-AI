package com.example.educonnect;

import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.widget.VideoView;
import androidx.appcompat.app.AppCompatActivity;

public class SplashActivity extends AppCompatActivity {
    private static final String TAG = "SplashActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG, "onCreate: SplashActivity started");

        setContentView(R.layout.activity_splash);

        try {
            // Find VideoView
            VideoView videoView = findViewById(R.id.splashVideo);
            if (videoView == null) {
                Log.e(TAG, "Error: VideoView is null!");
                navigateToMain(); // If VideoView fails, go to login screen
                return;
            }

            // Set the video
            Uri videoUri = Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.splash_video);
            Log.d(TAG, "Video URI: " + videoUri.toString());
            videoView.setVideoURI(videoUri);

            // Start video
            videoView.start();
            Log.d(TAG, "Video started");

            // Move to login page after video ends
            videoView.setOnCompletionListener(mp -> {
                Log.d(TAG, "Video completed, navigating to MainActivity");
                navigateToMain();
            });

            // Failsafe: Move to login after 5 sec if video fails
            videoView.postDelayed(this::navigateToMain, 3000);

        } catch (Exception e) {
            Log.e(TAG, "Error in SplashActivity: " + e.getMessage(), e);
            navigateToMain();
        }
    }

    private void navigateToMain() {
        Log.d(TAG, "Navigating to MainActivity...");
        startActivity(new Intent(SplashActivity.this, MainActivity.class));
        finish();
    }
}
