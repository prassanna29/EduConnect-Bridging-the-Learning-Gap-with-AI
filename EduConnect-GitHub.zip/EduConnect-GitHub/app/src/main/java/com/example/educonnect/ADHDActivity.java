package com.example.educonnect;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;
import android.speech.tts.TextToSpeech;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Locale;

public class ADHDActivity extends AppCompatActivity {

    private EditText inputText;
    private TextView outputText;
    private Button summarizeBtn, speakBtn, focusModeBtn;
    private SeekBar textSizeSeekBar;
    private TextToSpeech textToSpeech;
    private boolean isFocusMode = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adhd);

        inputText = findViewById(R.id.inputText);
        outputText = findViewById(R.id.outputText);
        summarizeBtn = findViewById(R.id.summarizeBtn);
        speakBtn = findViewById(R.id.speakBtn);
        focusModeBtn = findViewById(R.id.focusModeBtn);
        textSizeSeekBar = findViewById(R.id.textSizeSeekBar);

        textToSpeech = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                textToSpeech.setLanguage(Locale.US);
            }
        });

        summarizeBtn.setOnClickListener(v -> summarizeText());
        speakBtn.setOnClickListener(v -> speakText());
        focusModeBtn.setOnClickListener(v -> toggleFocusMode());

        textSizeSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                outputText.setTextSize(14 + progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });
    }

    private void summarizeText() {
        String input = inputText.getText().toString();
        if (!input.isEmpty()) {
            String summarizedText = input.length() > 50 ? input.substring(0, 50) + "..." : input;
            outputText.setText(summarizedText);
        }
    }

    private void speakText() {
        String text = outputText.getText().toString();
        if (!text.isEmpty()) {
            textToSpeech.speak(text, TextToSpeech.QUEUE_FLUSH, null, null);
        }
    }

    private void toggleFocusMode() {
        isFocusMode = !isFocusMode;
        if (isFocusMode) {
            outputText.setBackgroundColor(getResources().getColor(android.R.color.black));
            outputText.setTextColor(getResources().getColor(android.R.color.white));
            focusModeBtn.setText("Disable Focus Mode");
        } else {
            outputText.setBackgroundColor(getResources().getColor(android.R.color.white));
            outputText.setTextColor(getResources().getColor(android.R.color.black));
            focusModeBtn.setText("Enable Focus Mode");
        }
    }

    @Override
    protected void onDestroy() {
        if (textToSpeech != null) {
            textToSpeech.stop();
            textToSpeech.shutdown();
        }
        super.onDestroy();
    }
}
