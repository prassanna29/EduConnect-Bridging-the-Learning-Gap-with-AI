package com.example.educonnect;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.fragment.app.Fragment;

public class ProgressFragment extends Fragment {

    private TextView progressTextView;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_progress, container, false);
        progressTextView = view.findViewById(R.id.progressTextView);

        // Mock progress
        progressTextView.setText("Chapters Completed: 3/5\nScore Average: 82%");

        return view;
    }
}
