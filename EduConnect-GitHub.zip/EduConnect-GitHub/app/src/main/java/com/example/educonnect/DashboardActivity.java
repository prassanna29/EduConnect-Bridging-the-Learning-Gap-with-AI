package com.example.educonnect;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class DashboardActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    DashboardAdapter adapter;
    List<DashboardItem> dashboardItems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2)); // 2 cards per row

        // Add dashboard items
        dashboardItems = new ArrayList<>();
        dashboardItems.add(new DashboardItem("Listen & Learn", R.drawable.blind));
        dashboardItems.add(new DashboardItem("See & Sign", R.drawable.deaf));
        dashboardItems.add(new DashboardItem("Easy Read", R.drawable.dyslexia));
        dashboardItems.add(new DashboardItem("Stay Focused", R.drawable.adhd));
        dashboardItems.add(new DashboardItem("Explore & Learn", R.drawable.adaptive_learning));

        adapter = new DashboardAdapter(this, dashboardItems, this::onItemClick);
        recyclerView.setAdapter(adapter);
    }

    private void onItemClick(int position) {
        Intent intent;
        switch (position) {
            case 0: // Blind Assist
                intent = new Intent(this, BlindAssistActivity.class);
                break;
            case 1: // Deaf Assist
                intent = new Intent(this, DeafAssistActivity.class);
                break;
            case 2: // Dyslexia Help
                intent = new Intent(this, DyslexiaActivity.class);
                break;
            case 3: // ADHD Support
                intent = new Intent(this, ADHDActivity.class);
                break;
            case 4: // Adaptive Learning
                intent = new Intent(this, AdaptiveLearningActivity.class);
                break;
            default:
                return;
        }
        startActivity(intent);
    }
}
