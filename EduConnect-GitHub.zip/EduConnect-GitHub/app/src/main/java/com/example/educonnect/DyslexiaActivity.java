package com.example.educonnect;

import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Locale;

public class DyslexiaActivity extends AppCompatActivity {

    private EditText inputText;
    private TextView outputText;
    private Button summarizeBtn, speakBtn, changeFontBtn;
    private SeekBar textSizeSeekBar, spacingSeekBar;
    private Spinner backgroundSpinner, fontSpinner;
    private TextToSpeech textToSpeech;
    private String selectedFont = "Normal"; // Stores selected font

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dyslexia);

        inputText = findViewById(R.id.inputText);
        outputText = findViewById(R.id.outputText);
        summarizeBtn = findViewById(R.id.summarizeBtn);
        speakBtn = findViewById(R.id.speakBtn);
        changeFontBtn = findViewById(R.id.changeFontBtn);
        textSizeSeekBar = findViewById(R.id.textSizeSeekBar);
        spacingSeekBar = findViewById(R.id.spacingSeekBar);
        backgroundSpinner = findViewById(R.id.backgroundSpinner);
        fontSpinner = findViewById(R.id.fontSpinner);

        outputText.setMovementMethod(new ScrollingMovementMethod());

        // 🔹 Fix: Set Spinner Adapters
        String[] backgroundOptions = {"White", "Yellow", "Gray", "Blue"};
        ArrayAdapter<String> backgroundAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, backgroundOptions);
        backgroundSpinner.setAdapter(backgroundAdapter);

        String[] fontOptions = {"Normal", "Bold", "Italic"};
        ArrayAdapter<String> fontAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, fontOptions);
        fontSpinner.setAdapter(fontAdapter);

        // 🔹 Fix: Initialize TextToSpeech
        textToSpeech = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                textToSpeech.setLanguage(Locale.US);
            }
        });

        speakBtn.setOnClickListener(v -> {
            String text = outputText.getText().toString().trim();
            if (!text.isEmpty() && !text.equals("Summary will appear here")) {
                textToSpeech.speak(text, TextToSpeech.QUEUE_FLUSH, null, null);
            } else {
                Toast.makeText(DyslexiaActivity.this, "No valid text to read!", Toast.LENGTH_SHORT).show();
            }
        });




        textSizeSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                outputText.setTextSize(progress + 14);
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        spacingSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                outputText.setLineSpacing(progress, 1.2f);
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        backgroundSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                int[] colors = {Color.WHITE, Color.YELLOW, Color.LTGRAY, Color.BLUE}; // Use defined colors
                outputText.setBackgroundColor(colors[position]);
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });


        fontSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedFont = (String) parent.getItemAtPosition(position);
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });

        changeFontBtn.setOnClickListener(v -> applyFontStyle());
    }

    private void applyFontStyle() {
        switch (selectedFont) {
            case "Normal": outputText.setTypeface(null, Typeface.NORMAL); break;
            case "Bold": outputText.setTypeface(null, Typeface.BOLD); break;
            case "Italic": outputText.setTypeface(null, Typeface.ITALIC); break;
        }
    }

    private void summarizeText() {
        String input = inputText.getText().toString();
        if (input.isEmpty()) {
            Toast.makeText(this, "Enter text to summarize!", Toast.LENGTH_SHORT).show();
            return;
        }
        String[] sentences = input.split("\\.");
        StringBuilder summary = new StringBuilder();
        for (int i = 0; i < Math.min(2, sentences.length); i++) {
            summary.append(sentences[i]).append(".");
        }
        outputText.setText(summary.toString());
    }

    @Override
    protected void onDestroy() {
        if (textToSpeech != null) {
            textToSpeech.stop();
            textToSpeech.shutdown();
        }
        super.onDestroy();
    }
}
