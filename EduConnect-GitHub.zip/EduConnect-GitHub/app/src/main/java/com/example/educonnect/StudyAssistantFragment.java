package com.example.educonnect;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.fragment.app.Fragment;

public class StudyAssistantFragment extends Fragment {

    private EditText userQuestion;
    private Button getAnswerBtn;
    private TextView answerOutput;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_study_assistant, container, false);

        userQuestion = view.findViewById(R.id.userQuestion);
        getAnswerBtn = view.findViewById(R.id.getAnswerBtn);
        answerOutput = view.findViewById(R.id.answerOutput);

        getAnswerBtn.setOnClickListener(v -> {
            String question = userQuestion.getText().toString().trim();
            if (TextUtils.isEmpty(question)) {
                Toast.makeText(getContext(), "Please enter a question", Toast.LENGTH_SHORT).show();
            } else {
                // Simulated AI response
                answerOutput.setText("AI Response: " + generateMockAnswer(question));
            }
        });

        return view;
    }

    private String generateMockAnswer(String question) {
        return "This is a sample AI answer for: " + question;
    }
}
